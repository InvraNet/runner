﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Runtime.CompilerServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace gaming
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string filePath = textBox1.Text;
            if (checkBox1.Checked)
            {
                runasAdmin();
            }
            else runas();
        }
        private void runasAdmin()
        {
            string filePath = textBox1.Text;
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = filePath;
            startInfo.Verb = "runas"; // This will prompt for elevation (admin rights)

            try
            {
                Process.Start(startInfo);
            }
            catch (System.ComponentModel.Win32Exception)
            {
                MessageBox.Show("Runner couldn't launch this resource! Have you typed it in correctly?",
                                "Whoops!",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        private void runas()
        {
            string filePath = textBox1.Text;
            try
            {
                Process.Start(filePath);
            }
            catch (System.ComponentModel.Win32Exception)
            {
                MessageBox.Show("Runner couldn't launch this resource! Have you typed it in correctly?",
                                "Whoops!",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
 
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {                Process.Start(textBox1.Text);
        } else if (e.KeyCode == Keys.E) 
            {
                var proc = new ProcessStartInfo();
                proc.UseShellExecute = true;
                proc.WorkingDirectory = Environment.CurrentDirectory;
                proc.FileName = Application.ExecutablePath;
                proc.Verb = "runas";

                try
                {
                    Process.Start(proc);
                }
                catch (Exception)
                {
                    Console.WriteLine("Failed to elevate.");
                    return;
                }

                Application.Exit();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
